let m = 20;
let posX= [];
let posY= [];

function setup() {
  createCanvas(400, 400);
  
 let numX = 25;
     let numY = 25;
  
}

function draw() {
  background(220);
  
  push ();
  line (30, 30, 10, 30)
  
  
  pop ();
  
}