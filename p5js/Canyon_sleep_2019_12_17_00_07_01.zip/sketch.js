let angle = 0.0;
let jitter = 0.3;

function setup() {
  createCanvas(650, 650);
  noStroke();
  fill(255);
  //Draw the rectangle from the center and it will also be the
  //rotate around that center
  rectMode(CENTER);
}

function draw() {
  background(0);

  // during even-numbered seconds (0, 2, 4, 6...) add jitter to
  // the rotation
  if (second() % 4 === 0) {
    jitter = random(-0.2, 0.2);
  }
  
  angle = angle + jitter;
  
  let c = cos(angle);
  
  translate(width / 2, height / 2);
 
  rotate(c);
  triangle(250, 10, 10, 10, 200, 250 );
  
}
