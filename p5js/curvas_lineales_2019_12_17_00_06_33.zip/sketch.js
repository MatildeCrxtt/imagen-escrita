function setup() {
  createCanvas(500, 500);
  cursor(CROSS);
}

function draw() {
  background(0);

  
  let numX = 50; // número de elementos en X´
  let numY = 10; // número de elementos en Y´
  
  let m = 20;    // margen
  
  // calculo los espaciadores de x e y
  let spx = (width - 2*m)/(numX - 1);
  let spy = (height - 2*m)/(numY - 1);
  
  // doble for loop
  for (let y = 0; y < numY; y++) {
    for (let x = 0; x < numX; x++) {
      
      // calculo la distancia con el mouse
      let d = dist(mouseX, mouseY, m + x*spx, m + y*spy);
      // mapeo la distancia a un ángulo´
      let r = map(d, 0, width, 0, TWO_PI);
      
      // reseteo la matriz
      push();
      translate(m + x*spx, m + y*spy); // traslado al punto de la grilla
      rotate(r); // roto en un ángulo proporcional a la distancia
      
      rotate(r); // roto en un ángulo proporcional a la distancia
      stroke(255)
      line(0, 0, spx/1.1, 0); // hago una línea horizontal´
      fill (255)
      ellipse(0, 0, 3, 3);
      pop();
    }
  }
}