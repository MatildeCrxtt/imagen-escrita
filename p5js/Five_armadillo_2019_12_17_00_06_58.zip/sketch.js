function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}

/*void setup() {
  size(400,400);
  smooth();
}
int margin = 100;
int spacer = 20;

void draw() {
  background(255);
  for (int x=1; x<=10; x++){
    for (int y=1; y<=10; y++){
      stroke(0);
      line(margin+x*spacer,margin+y*spacer,x*mouseX/PI,y*mouseY/PI);
    }
  }   
}
*/
