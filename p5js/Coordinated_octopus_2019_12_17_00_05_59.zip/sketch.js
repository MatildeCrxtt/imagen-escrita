function setup() {
  createCanvas(400, 400);

let pelotaX, pelotaY; 
let value = 0

function draw() {
  background(150);
  beginShape();
  speed = sin(millis()/180) * 20
  
    pelotaX = mouseX = width / 2;
  pelotaY = mouseY = height / 2;
  //noCursor(); // sin cursor

  fill(value);
  
vertex(76, 84); 
vertex(96, 75); 
vertex(124, 72); 
vertex(145, 85); 
vertex(159, 115); 
2
vertex(159, 115); 
vertex(234, 231);  
vertex(250, 264); 
vertex(115, 263); 
vertex(105, 261); 
vertex(91, 231); 
vertex(81, 208); 
vertex(76, 187); 
vertex(72, 159); 
vertex(71, 107); 

  endShape(CLOSE);
  
  
  
  push()
  fill (255)
  text('A', 10, 40);
  text('Q', 18, 80);
  text('U', 26, 120);
  text('Í', 32, 160);
  
   text('A', 300, 260);
  text('L', 310, 220);
  text('L', 318, 180);
  text('Á', 330, 140);
  pop()
  
  
  push ()
  line (235, 233, 370, 30)
  line (78, 84, 370, 30)
  line (250, 265, 370, 30)
  line (105, 262, 370, 30)
  line (145, 87, 370, 30)
  pop()
  
  
  push ()
  fill (200, 50, 0)
  ellipse (114, 125, 20, 60)
  fill (250)
  circle (114, speed + 125, 10)
  pop()
  
  push()
  fill (200)
  circle (100, 300, 50)
  fill (0)
  circle (100, 300, 20)
  pop()

  
}
function mouseMoved() {
  value = value + 5;
  if (value > 255) {
    value = 0;
  }
}

function mousePressed() {
  console.log("vertex(" + mouseX + ", " + mouseY + ");");
    }
  