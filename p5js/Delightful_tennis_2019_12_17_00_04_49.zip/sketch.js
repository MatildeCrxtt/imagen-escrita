let ang = 0 ;
let r = 150;
let a, b;

function setup() {
  createCanvas(600, 600);
  stroke(255);
  noFill();
}

function draw() {
  background(220);
  strokeWeight(3);
  background(0);
  let inc = PI / 300;
  let x, y;

  push();
  translate(width * .50, height * .50);
  stroke(200, 100, 100);
  noFill();
  ellipse(0, 0, 2 * r, 2 * r);
  rotate(ang);
  stroke(255);
  line(0, 0, r, 0);
  line(0, r, 0, 0);
  pop();
  
   push();
  translate(width * .50, height * .25);
  stroke(200, 100, 100);
  noFill();
  ellipse(0, 0, 2 * r, 2 * r);
  rotate(ang);
  stroke(255);
  line(0, 0, r, 0);
  line(0, r, 0, 0);
  pop();
  
  translate(width * .25, height * .50);
  stroke(200, 100, 100);
  noFill();
  ellipse(0, 0, 2 * r, 2 * r);
  rotate(ang);
  stroke(255);
  line(0, 0, r, 0);
  line(0, r, 0, 0);
  pop();
  
  
  

  
 
}