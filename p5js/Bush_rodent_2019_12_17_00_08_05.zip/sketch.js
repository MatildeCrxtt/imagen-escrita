//sol lewitt cuadrado releno de lineas horizontales con un triangulo equilatero al cento con la base hacia arriba relleno de lineas verticales http://willcwillc.blogspot.com/2011/04/i-went-into-mountains-of-massachusetts.html

function setup() {
  createCanvas(400, 400);
  
}

function draw() {
  background(220);
  strokeWeight(4);
  stroke(51);


  let numX = 44; // número de elementos en X´

  let m = 20; // margen
  
  line(400, 5, 0, 5)
  
  // calculo los espaciadores de x 
  let spx = (width - 2 * m) / (numX - 1);
  
  triangle(200, 250, 78, , 262, 75);
 


}