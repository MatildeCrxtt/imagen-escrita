function setup() {
  createCanvas(500, 500);
 
    let r = random(50);
}

function draw() {
  background(220);
  
  
  //circle (250, 60, 60)
  circle (100, 400, 50)
  circle (400, 100, 50)
  circle (250, 250, 50)
  triangle (400, 400, 400, 100, 100, 100)
  triangle (100, 100, 100, 200, 200, 200 )
  triangle (200, 400, 100, 400, 100, 300)
  triangle (400, 400, 300, 400, 300, 300)
  fill (100, 0 , 60)
  
  
}