/**
pelota cursor no funco
*/

let pelotaX; pelotaY;
let ROCE = 0.025;
let diam = 12


function setup() {
  createCanvas(400, 400);
  
   pelotaX = mouseX = width / 2;
  pelotaY = mouseY = height / 2;
  noCursor();
  
}

function draw() {
  background(220);
  
  
   pelotaX += difX * ROCE;
  pelotaY += difY * ROCE;


  pelota(pelotaX, pelotaY);
  
}

function pelota(x, y){

  let d = dist(pelotaX, pelotaY, mouseX, mouseY);

}